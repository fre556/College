/**
 * @(#)Drawing.java
 *
 *
 * @author Graham Jordan
 * @version 1.00 2014/12/2
 */

import javax.swing.*;
import java.awt.*;
public class Drawing extends JFrame{

	//constructor
    public Drawing() {
    	super("drawing");
    	setSize(400,400);
    	setVisible(true);
    }//end constructor

    //paint
    public void paint(Graphics g){
    	g.drawRect(50,150,300,150);
    	g.drawOval(175,200,50,50);
    	g.drawRect(70,200,40,50);
    	g.drawLine(200,170,200,280);
    	g.drawRect(70,170,260,110);
    	g.drawRect(290,200,40,50);


    }//end paint

    //main
    public static void main(String args[]){
    	new Drawing();

    }//end main method

}