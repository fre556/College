var hierarchy =
[
    [ "MonoBehaviour", null, [
      [ "DestroyWhenHit", "class_destroy_when_hit.html", null ],
      [ "DoorBehavior", "class_door_behavior.html", null ],
      [ "PlayerBehavior", "class_player_behavior.html", null ],
      [ "PlayerGUI", "class_player_g_u_i.html", null ],
      [ "RolloverButton", "class_rollover_button.html", null ],
      [ "TeleporterBehavior", "class_teleporter_behavior.html", null ],
      [ "WinGameWhenHit", "class_win_game_when_hit.html", null ]
    ] ]
];