var class_destroy_when_hit =
[
    [ "OnTriggerEnter", "class_destroy_when_hit.html#a38153fd7972f3ffa615233c4c99560c5", null ]
];