var searchData=
[
  ['gethealth',['GetHealth',['../class_player_behavior.html#a0faa2ba0078bc2b01448a4af5acfcd81',1,'PlayerBehavior']]],
  ['getlivesleft',['GetLivesLeft',['../class_player_behavior.html#ae1b9510a428e33dc83e8cd6f036c53cd',1,'PlayerBehavior']]]
];
