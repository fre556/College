var searchData=
[
  ['update',['Update',['../class_player_behavior.html#ae3a9e7dc00f1cde5b8dd0e2fac63620a',1,'PlayerBehavior.Update()'],['../class_teleporter_behavior.html#a02a57d44bde0f18bd9161891c3bf7d80',1,'TeleporterBehavior.Update()']]]
];
