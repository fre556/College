var class_win_game_when_hit =
[
    [ "OnTriggerEnter", "class_win_game_when_hit.html#a11be0ed0a1bc2aa9171caf71331ee086", null ],
    [ "teleporter", "class_win_game_when_hit.html#a05175f34ceda1e9ea4cb00ece2bec71b", null ]
];