using UnityEngine;
using System.Collections;

/** 
 * standard behavior class for rollover buttons that will load a new scene when clicked
 */
public class RolloverButton : MonoBehaviour {
	/** public (inspector editable) integer number of level to load when button clicked */
	public int levelToLoadOnClick = 0;
	
	/** reference to button image when mouse not over it */
	public Texture2D normalImage;
	
	/** reference to mouse over button image */
	public Texture2D rolloverImage;
	
	/** when mouse over image, change image to rollover image */
	private void OnMouseOver(){
	}
	
	/** when mouse no longer over image, change back to normal image */
	private void OnMouseExit(){
	}
	
	/** when mouse button clicked, make application load scene for given integer */
	private void OnMouseUp(){
	}
}
