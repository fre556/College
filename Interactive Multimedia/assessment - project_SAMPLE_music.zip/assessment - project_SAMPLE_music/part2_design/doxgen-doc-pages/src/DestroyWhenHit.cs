using UnityEngine;
using System.Collections;

/**
 * make parent game object Destroy() itself when hit by anything!
 * 
 * Note: assumes object doing the hitting will have appropriate behavior in its own OnTriggerEnter() method ...
 */
public class DestroyWhenHit : MonoBehaviour {
	
	/**
	 * Destroy() parent game object when collided with
	 */
	private void OnTriggerEnter(){
	}
}
