using UnityEngine;
using System.Collections;

/**
 * main class for Player's behavior logic
 * 
 * (store and update lives left, heath, pickups etc.)
 */
public class PlayerBehavior : MonoBehaviour {
	/** reference to pickup sound for: GREEN add health cube */
	public AudioClip greenPickupSound;

	/** reference to pickup sound for: RED lose health cube */
	public AudioClip redPickupSound;

	/** reference to pickup sound for: KEY pickup */
	public AudioClip keyPickupSound;

	/** reference to sound clip to indicate to user they have LOST A LIFE */
	public AudioClip loseLifeSound;

	/** boolean GETTER - whether or not player is carrying the key */
	public bool IsCarryingKey(){
		return carryingKey;
	}
	
	/** integer GETTER - number of lives player has left */
	public int GetLivesLeft(){
		return livesLeft;
	}
	
	/** float GETTER - how much health (0..100) the player hasleft */
	public float GetHealth(){
		return health;
	}
	
	/** number of lives left */
	private int livesLeft = 1;
	
	/** percentage health player has (0.0 - 100.0) */
	private float health = 100;
	
	/** flag to indicate if player is carrying the key */
	private bool carryingKey = false;
	
	/** actions for every frame:
	 * 
	 * <ol>
	 * 	<li>reduce health by 0.1
	 * 	<li>ensure health neven goes above 100
	 * 	<li>see if player should lose a life due to health going too low
	 */
	private void Update () {
	}
	
	/** if health less than 1, then make player lose a life (or lose game if no more lives left) */
	private void CheckLives(){
	}
	
	/** actions for when player loses a life:
	 * 
	 * <ol>
	 * 	<li>reduce player's lives left by 1
	 * 	<li>reset health back to 100%
	 * 	<li>play life lost sound
	 */
	private void LoseLife(){
	}
	
	/** actions when player hits something
	 * 
	 * <dl>
	 * 	<dt>tag 'red'
	 * 	<dd>reduce health, play bad sound
	 * 
	 * 	<dt>tag 'green'
	 * 	<dd>add to health, play good sound
	 * 
	 * 	<dt>tag 'key'
	 * 	<dd>sert flag to indicte player carrying key, play key pickup sound
	 * 
	 * 	<dt>tag 'door'
	 * 	<dd>set flag to indicate player no longer carrying key
	 * 		<br/>(and door should be responsible for it's own opening actions ...)
	 */

	private void OnTriggerEnter(Collider hit){
	}
}
