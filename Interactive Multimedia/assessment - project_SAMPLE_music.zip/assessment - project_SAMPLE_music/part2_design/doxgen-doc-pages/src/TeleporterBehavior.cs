using UnityEngine;
using System.Collections;

/**
 * level won behavior - for teleporter prefab
 */
public class TeleporterBehavior : MonoBehaviour {
	
	/**
	 * check each frame for when sound stops playing
	 * <br/>
	 * once sound completed, load scene 3 (level completed screen)
	 */
	private void Update () {
	}
}
