using UnityEngine;
using System.Collections;

/**
 * add a GUI to the players GO
 */
public class PlayerGUI : MonoBehaviour {
	/** reference to key icon image */
	public Texture2D keyIcon;
	
	/** reference to health progess bar image - 0% health */
	public Texture2D healthImage000;

	/** reference to health progess bar image - 5% health */
	public Texture2D healthImage005;
	
	/** reference to health progess bar image - 25% health */
	public Texture2D healthImage025;
	/** reference to health progess bar image - 50% health */
	public Texture2D healthImage050;
	/** reference to health progess bar image - 75% health */
	public Texture2D healthImage075;
	/** reference to health progess bar image - 100% health */
	public Texture2D healthImage100;

	/** reference to lifes left image - no lives left */
	public Texture2D livesLeftZeroIcon;

	/** reference to lifes left image - 1 life left */
	public Texture2D livesLeftOneIcon;
	
	/** reference to lifes left image - 2 lives left */
	private PlayerBehavior playerScriptedObject;

	/** player GUI initialisation 
	 *
	 * get and cache (store in private variable) a reference to the player's scripted behavior object
	 */
	private void Start(){
	}
	
	/**
	 * main GUI method:
	 * 
	 * <ol>
	 * 	<li>start a horizontal layout arrangement
	 * 	<li>display lives left
	 * 	<li>display current health status
	 * 	<li>display whether or not player is carrying the key
	 */
	private void OnGUI(){
	}
	
	/**
	 * display an appropriate image to show how many lives the player has left
	 */
	private void DisplayLivesLeft(){
	}
	
	/**
	 * display an appropriate image to show how much health the player has left
	 */
	private void DisplayHealthStatus(){
	}
	
	/**
	 * display an appropriate image to show whether player is carrying the key or not
	 */
	private void DisplayKeyStatus(){
	}
	
	/**
	 * helper function - given a float value of health, return the corresponding heath bar image
	 */
	private Texture2D HealthBarImage(float healthFloat){
	}
}
