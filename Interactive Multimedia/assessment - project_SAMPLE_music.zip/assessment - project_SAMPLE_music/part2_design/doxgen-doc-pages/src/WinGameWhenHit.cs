using UnityEngine;
using System.Collections;

/**
 * game win behavior - to be added to the target object that the player must reach to win the game
 */
public class WinGameWhenHit : MonoBehaviour {
	
	/** reference to a teleporter prefab object */
	public GameObject teleporter;
	
	/**
	 * when object hit:
	 * 
	 * <ol>
	 * 	<li> create a teleporter prefab instance
	 * 	<li>destroy parent game object
	 */
	private void OnTriggerEnter(){
	}

}
