using UnityEngine;
using System.Collections;

/**
 * behavior for a door sensor object
 * 
 * if sensor is hit, and player is carrying key, open the door
 */
public class DoorBehavior : MonoBehaviour {
	/** reference to scripted object in the player GO */
	public PlayerBehavior playerScriptedObject;
	
	/** reference to the door GO */
	public GameObject door;
	
	/** when hit do the following if player is carrying the key:
	 * 
	 * <ol>
	 * 	<li>make the door play its animation
	 * 	<li>destroy the parent door sensor GO
	 */
	private void OnTriggerEnter(){
	}
}
