﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

	public GameObject yesNoButtonGO;

	public AudioClip buzzerSound;
	public AudioClip chimeSound;

	//----- PUBLIC methods ---------
	public bool IsCarryingNoteC(){	return carryingNoteC;	}
	public bool IsCarryingNoteE(){	return carryingNoteE;	}
	public bool IsCarryingNoteG(){	return carryingNoteG;	}

	//--------- properties -------
	private bool carryingNoteC = false;
	private bool carryingNoteE = false;
	private bool carryingNoteG = false;

	//-------------------------------
	private void BadNoteAction()
	{
		// play bad note sound
		// lose life ?
		// reduce score ?
		//
		// do something here for picking up a bad note !
		print ("do BAD note pickup action here !");

		audio.PlayOneShot(buzzerSound);
		yesNoButtonGO.SetActive(true);
	}

	//-------------------------------
	private void OnTriggerEnter(Collider c)
	{
		string tag = c.tag;
		if("NoteC" == tag){	
			carryingNoteC = true;	
			audio.PlayOneShot(chimeSound);
		}
		
		if(c.CompareTag("NoteE")){	
			carryingNoteE = true;	
			audio.PlayOneShot(chimeSound);
		}
		
		if(c.CompareTag("NoteG")){	
			carryingNoteG = true;	
			audio.PlayOneShot(chimeSound);
		}
		
		if(c.CompareTag("NoteA")){	
			BadNoteAction();	
		}
	}


}
