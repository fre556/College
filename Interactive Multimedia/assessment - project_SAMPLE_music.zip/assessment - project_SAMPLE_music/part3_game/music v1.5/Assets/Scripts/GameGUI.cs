﻿using UnityEngine;
using System.Collections;

public class GameGUI : MonoBehaviour {
	public Player player;
	public Texture2D notesNone;
	public Texture2D notesC;
	public Texture2D notesE;
	public Texture2D notesG;
	public Texture2D notesCE;
	public Texture2D notesCG;
	public Texture2D notesEG;
	public Texture2D notesCEG;

	private CountdownTimer myTimer;

	//------------------------
	private void Start()
	{
		myTimer = GetComponent<CountdownTimer>();
	}

	//------------------------
	private void OnGUI()
	{
		DisplayTime();
		DisplayNotes();
	}

	//------------------------
	private void DisplayNotes()
	{
		bool carryingNoteC = player.IsCarryingNoteC();
		bool carryingNoteE = player.IsCarryingNoteE();
		bool carryingNoteG = player.IsCarryingNoteG();
		Texture2D chordIcon = ChordImage(carryingNoteC, carryingNoteE, carryingNoteG);
		int iconWidth = chordIcon.width;
		int iconHeight = chordIcon.height;
		// position at RIGHT hand side of screen
		float x = Screen.width - iconWidth;
		Rect noteRect = new Rect(x, 0, iconWidth, iconHeight);
		GUI.Label(noteRect, chordIcon);
	}

	//------------------------
	private Texture2D ChordImage(bool c, bool e, bool g)
	{
		if(c && e && g)	return notesCEG;
		else if(c && !e && !g)	return notesC;
		else if(!c && e && !g)	return notesE;
		else if(!c && !e && g)	return notesG;
		else if(c && e && !g)	return notesCE;
		else if(!c && e && g)	return notesEG;
		else if(c && !e && g)	return notesCG;
		else if(c && !e && g)	return notesCG;
		else return notesNone;
	}

	//------------------------
	private void DisplayTime()
	{
		int secondsLeft = myTimer.GetSecondsRemaining();
		string secondsLeftMessage = "Seconds left = " + secondsLeft;

		/*
		float proportionTimeLeft = myTimer.GetProportionTimeRemaining();
		string proportionLeftMessage = "proportion of time left = " + proportionTimeLeft;
		GUILayout.Label(proportionLeftMessage);
		*/

		float iconWidth = notesNone.width;
		float x = Screen.width - iconWidth;
		float textYStart = 300;
		float textYHeight = 200;
		Rect timeRect = new Rect(x, textYStart, iconWidth, textYHeight);
		GUI.Label(timeRect, secondsLeftMessage);
	}

}
