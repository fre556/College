﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour {
	public int countdownTotalSeconds = 3;

	private CountdownTimer myTimer;
	
	//------------------------
	private void Start()
	{
		myTimer = GetComponent<CountdownTimer>();
		myTimer.ResetTimer(countdownTotalSeconds);
	}

	//------------------------
	private void Update()
	{
		int secondsLeft = myTimer.GetSecondsRemaining();
		if(secondsLeft <= 0)
		{
			int gameOverSceneIndex = 1;
			Application.LoadLevel(gameOverSceneIndex);
		}
	}

}
